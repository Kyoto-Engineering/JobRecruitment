<?php include_once "inc/header.php";?>
 <?php include_once "../Classes/resume.php";?>

      <!-- sidebar menu: : style can be found in sidebar.less -->
 <?php include_once "inc/sidebar.php";?>    
 <?php
      $edu = new Resume();
      if (isset($_GET['delete'])) {
      $Did = $_GET['delete'];
      $delCat = $edu->delByid($Did);
    }
  ?>
  <?php
    if (!isset($_GET['application']) || $_GET['application'] == NULL ) {
        
      }else{
        $applicationId = $_GET['application'];
      }

?> 
  <?php 

    
    if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])){
        
        
        $addSchedule = $edu->interviewSchedule($_POST,  $applicationId);
    }
 
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Create Interview Schedule</h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <?php
        if (isset($addSchedule)) {
          echo $addSchedule;
        }
      ?>
      <div class="row">
      <div class="col-md-3">
        <form action="" method="post">
                                  <p> 
                                     <label for="sel1">Job Title</label>
                                        <select class="form-control" id="sellect" name="jId">
                                          <option>Select Job Title</option>
                                           <?php
                                             $getJob = $edu->getjobs($applicationId);
                                              if ($getJob) {
                                                while ($value = $getJob->fetch_assoc()) {
                                                  
                                            ?>
                                           <option value="<?php echo $value['jId'];?>" ><?php echo $value['jobtitle'];?></option>  
                                          <?php } } ?>    
                                        </select>
                                        
                                       
                                    <br>
                                  </p>
                                   <div class="form-group">
                                        <label for="pwd">InterView Date:</label>
                                        <input type="date" name="interviewdate" class="form-control" id="pwd">
                                  </div>

                                 
                                  <div class="form-group">
                                        <label for="pwd">Start Time:</label>
                                        <input type="Time" name="starttime" class="form-control" id="pwd">
                                  </div>

                                  <div class="form-group">
                                        <label for="pwd">End Time:</label>
                                        <input type="Time" name="endtime" class="form-control" id="pwd">
                                  </div>

                                   

                                   <div class="form-group">
                                        <label for="exampleTextarea">Venue:</label>
                                        <textarea class="form-control" name="venue" id="exampleTextarea" rows="3"></textarea>
                                  </div>

                                  <p><button type="submit" name="submit" class="btn btn-primary">Create Schedule</button></p>

        </form>
      </div>

      <div class="col-md-9">

        <table class="table">
    <thead>
    
      <tr>
        <th>JobTitle</th>
        <th>Interview Date</th>
        <th>Start</th>
        <th>End</th>
        <th>Venue</th>
        <th>Action</th>
        
      </tr>
    </thead>
    <tbody>
    <?php 
        $getTime = $edu->getInschedule();
        if ($getTime) {
            while ($value = $getTime->fetch_assoc()) {
       
    ?>
      <tr class="success">
        <td><?php echo $value['jobtitle'];?></td>
        <td><?php echo $value['interviewdate'];?></td>
        <td><?php echo $value['starttime'];?></td>
        <td><?php echo $value['endtime'];?></td>
        <td><?php echo $value['venue'];?></td>
        <td><a href="edit_schedule.php?edit=<?php echo $value['id'];?>"><span class="glyphicon glyphicon-pencil"></span></a>&nbsp;||&nbsp;<a onclick="return confirm('Are you Sure Want to Delete!')" href="?delete=<?php echo $value['id'];?>">Delete</a></td>
      </tr>
      <?php } } ?>
    </tbody>
</table>

      </div>
      </div>
      <!-- /.row -->

      
      <!-- Main row -->
      <div class="row">
        
            </div>
           
    
         

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 <?php include_once "inc/footer.php";?> 