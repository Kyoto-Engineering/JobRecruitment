 <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="active"><a href="create_degree.php"><i class="fa fa-circle-o"></i> Create Degree</a></li>

            <li><a href="create_department.php"><i class="fa fa-circle-o"></i>Create Depertment</a></li>
            <li><a href="createjob_title.php"><i class="fa fa-circle-o"></i>Create JobTitle</a></li>
            <li><a href="createjob.php"><i class="fa fa-circle-o"></i>Create Job</a></li>
            <li><a href="create_specialization.php"><i class="fa fa-circle-o"></i>Create Specialization</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-eye" aria-hidden="true"></i>
            <span>View ALL</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="#"><i class="fa fa-circle-o"></i>Job Titles</a></li>
            <li><a href="depertment_list.php"><i class="fa fa-circle-o"></i> Depertments</a></li>
            <li><a href="joblist.php"><i class="fa fa-circle-o"></i> Job List</a></li>
            <li><a href="specialization_list.php"><i class="fa fa-circle-o"></i> Specializations</a></li>
          </ul>
        </li>

       
        <li class="treeview">
          <a href="#">
            <i class="fa fa-book" aria-hidden="true"></i>
            <span>Education</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="pages/charts/#"><i class="fa fa-circle-o"></i> ChartJS</a></li>
            <li><a href="pages/charts/#"><i class="fa fa-circle-o"></i> Morris</a></li>
            <li><a href="pages/charts/#"><i class="fa fa-circle-o"></i> Flot</a></li>
            <li><a href="pages/charts/#"><i class="fa fa-circle-o"></i> Inline charts</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users" aria-hidden="true"></i>
            <span>Applicant List</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="applied_job.php"><i class="fa fa-circle-o"></i>Applied Jobs</a></li>
            <li><a href="pages/charts/#"><i class="fa fa-circle-o"></i> Depertments</a></li>
            <li><a href="pages/charts/#"><i class="fa fa-circle-o"></i> Job List</a></li>
            <li><a href="pages/charts/#"><i class="fa fa-circle-o"></i> Specializations</a></li>
          </ul>
        </li>
       
      
      
        
      
       
     
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>